package com.example.tablayout;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class RegisterFragment extends Fragment {

    private EditText etUsername, etEmail, etPhone, etPassword;
    private CheckBox cbTerms;
    private Button btnRegister;


    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        // Initialize views
        etUsername = view.findViewById(R.id.RegisterUsername);
        etEmail = view.findViewById(R.id.RegisterEmail);
        etPhone = view.findViewById(R.id.RegisterPhone);
        etPassword = view.findViewById(R.id.RegisterPassword);
        cbTerms = view.findViewById(R.id.TermsCheckbox);
        btnRegister = view.findViewById(R.id.RegisterButton);

        // Set register button click listener (navigates to LoginFragment)
        btnRegister.setOnClickListener(v -> navigateToLogin());

        return view;
    }

    private void validateAndRegister() {
        String username = etUsername.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Perform validation
        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Nama pengguna diperlukan");
            return;
        }

        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Email yang valid diperlukan");
            return;
        }

        if (TextUtils.isEmpty(phone) || phone.length() != 10) {
            etPhone.setError("Nomor telepon valid diperlukan");
            return;
        }

        if (TextUtils.isEmpty(password) || password.length() < 6) {
            etPassword.setError("Kata sandi minimal 6 karakter");
            return;
        }

        if (!cbTerms.isChecked()) {
            Toast.makeText(getActivity(), "Setujui syarat dan ketentuan", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(getActivity(), "Pendaftaran Berhasil!", Toast.LENGTH_SHORT).show();
    }

    private void navigateToLogin() {
        // Navigate to LoginFragment
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_register, new LoginFragment());
        transaction.addToBackStack(null);
        transaction.commit();
    }
}