package com.example.tablayout;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class LoginFragment extends Fragment {

    private EditText etUsername, etPassword;
    private Button btnLogin;
    private TextView tvRegister;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // Initialize views
        etUsername = view.findViewById(R.id.Username);
        etPassword = view.findViewById(R.id.Password);
        btnLogin = view.findViewById(R.id.loginButton);
        tvRegister = view.findViewById(R.id.registerText);

        // Set login button click listener (navigates to HomeFragment)
        btnLogin.setOnClickListener(v -> validateAndLogin());

        // Set register text click listener (navigates to RegisterFragment)
        tvRegister.setOnClickListener(v -> navigateToRegister());

        return view;
    }

    private void validateAndLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Check if fields are empty
        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Nama pengguna diperlukan");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Kata sandi diperlukan");
            return;
        }

        // Simulate login check (replace with actual login logic)
        if (username.equals("aul") && password.equals("aul123")) {
            Toast.makeText(getActivity(), "Login Berhasil!", Toast.LENGTH_SHORT).show();
            navigateToHome();
        } else {
            Toast.makeText(getActivity(), "Nama pengguna atau kata sandi salah", Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToRegister() {
        // Navigate to RegisterFragment
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_login, new RegisterFragment());
        transaction.addToBackStack(null);
        transaction.commit();
    }

    private void navigateToHome() {
        // Navigate to HomeFragment
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_login, new HomeFragment());
        transaction.addToBackStack(null);
        transaction.commit();
    }
}